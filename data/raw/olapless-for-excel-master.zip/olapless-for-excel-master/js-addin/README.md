# excel-add-in

> Olapless Excel Add-In

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at http://localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report

# run unit tests
npm run unit

# run all tests
npm test
```

<https://docs.microsoft.com/en-us/javascript/api/excel?view=excel-js-preview>

## This will compile the static resources to be served for Excel Task pane

mvn install -Dskip.npm=false

## Installation in Excel

For Excel Online:
<https://docs.microsoft.com/en-us/office/dev/add-ins/testing/sideload-office-add-ins-for-testing#sideload-an-office-add-in-in-office-on-the-web>

For debug under Windows:
- install on localhost: <https://docs.microsoft.com/en-us/office/dev/add-ins/testing/create-a-network-shared-folder-catalog-for-task-pane-and-content-add-ins>
- setup debug with tools under Windows: <https://docs.microsoft.com/en-us/office/dev/add-ins/testing/debug-add-ins-using-f12-developer-tools-on-windows-10>

For debug under macOS:
<https://docs.microsoft.com/en-us/office/dev/add-ins/testing/sideload-an-office-add-in-on-ipad-and-mac>

### MacOS special note: BEWARE PLUGIN WILL APPEAR ONLY ON CARET NEXT TO 'My Add-Ins'

## LOCALHOST development

<https://docs.microsoft.com/en-us/office/troubleshoot/error-messages/cannot-open-add-in-from-localhost>

### Enable DEBUG mode in TaskPane

<https://docs.microsoft.com/en-us/office/dev/add-ins/testing/debug-office-add-ins-on-ipad-and-mac>

the simple way to enable debug on any OS is to use the web office 365 <https://www.office.com/launch/excel>
from a modern browser
- launch local server on https mode
```bash
# serve with hot reload at https://localhost:8080
npm run dev:https
```
- from office 365 Excel go to Insert ➞ Office Add-ins  
- from the Add-ins window, upload `manifest_local_https.xml` and add it
- use the usual debug tools from your browser, typically Ctrl+Shift+i to open the console from Chrome

### Create, run, and test Add-in code snippets from within Excel

<https://appsource.microsoft.com/en-US/product/office/wa104380862?signInModalType=1&ctaType=1>

## Deployment and publish on Production

### By Share Point catalog

<https://docs.microsoft.com/en-us/office/dev/add-ins/publish/publish-task-pane-and-content-add-ins-to-an-add-in-catalog#publish-an-office-add-in>

### Authentication
- guide lines: <https://docs.microsoft.com/en-us/office/dev/add-ins/develop/auth-with-office-dialog-api>
![Auth Flow](https://docs.microsoft.com/en-us/office/dev/add-ins/images/taskpane-dialog-processes.gif)
- samples: <https://github.com/OfficeDev/Office-Add-in-Dialog-API-Simple-Example/tree/d76c5958b771c062c6c5ad28c223a3d532b61555>
- how to use dialog in Office Addin: <https://docs.microsoft.com/en-us/office/dev/add-ins/develop/dialog-api-in-office-add-ins>
- know issues & pitfalls: 
    - dialog not open: <https://github.com/OfficeDev/office-js/issues/132>
    - cannot communicate between the dialog and its parent: <https://github.com/OfficeDev/office-js/issues/482>
    - refuse to display iframe on web office: <https://github.com/OfficeDev/office-js/issues/925>

## Various

- Excel Add-in [requires https](https://docs.microsoft.com/en-us/office/dev/add-ins/quickstarts/excel-quickstart-jquery?tabs=yeomangenerator#try-it-out), even on development environment

  [enable self signed certificates on localhost](https://github.com/OfficeDev/Office-add-in-Nodejs-ServerAuth/wiki/Trust-your-self-signed-certificate)
  
- The web application can be managed by both SpringBoot backend (full-fledged server) and NodeJs backend (easily serving static resources)
