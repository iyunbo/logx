import * as api from "./ApiHelper.js";
import * as columnHelper from "./ColumnHelper.js";

export async function clearAll(grid) {
  grid.username = "";
  grid.fields = [];
  grid.bookmarks = [];
  grid.currencies = [];
  await clearTable(grid);
}


export function init(grid) {
  grid.excelTiming = performance.now() - grid.excelTiming;
  grid.serverTiming = performance.now();
  api.discovery(data => {
    grid.serverTiming = performance.now() - grid.serverTiming;
    const dataset = data["datasets"][0];
    const cols = dataset["columns"];
    for (const key in cols) {
      if (cols.hasOwnProperty(key)) {
        grid.fields.push(
          {
            name: key,
            type: cols[key]["type"],
            selected: false,
            selectedValues: [],
          }
        );
      }
      grid.dataset = dataset["id"];
      grid.currencies = data["currencies"];
    }
  });
  api.bookmarks((data) => {
    grid.bookmarks = data;
  });
}


export function selectValue(valueColumn, grid) {
  grid.showModal = false;
  const selectedValue = {};
  selectedValue[valueColumn.name] = {"$in": valueColumn.selectedValues};
  grid.where = grid.where.filter(c => {
    return c[valueColumn.name] === undefined || !("$in" in c[valueColumn.name]);
  });
  grid.where.push(selectedValue);
}


export function selectField(field, grid) {
  if (field.selected) {
    if (columnHelper.isNumeric(field)) {
      columnHelper.addColumn(grid.values, field);
    } else {
      columnHelper.addColumn(grid.columns, field);
    }
  } else {
    columnHelper.removeColumn(grid.columns, field);
    columnHelper.removeColumn(grid.values, field);
  }
}


export const empty = {
  fields: [],
  filters: [],
  columns: [],
  values: [],
  where: [],
  currencies: [],
  referenceCcy: "EUR",
  showModal: false,
  filterColumn: {},
  dataset: "",
  username: "Please login",
  serverTiming: 0,
  excelTiming: performance.now(),
  bookmarks: [],
  authenticated: false
};


export function loadBookmark(bookmark, grid) {
  const query = bookmark.query;
  const where = query["where"];
  grid.columns = query["select"]
    .filter(col => !col.includes("."))
    .map(col => {
      return {name: col, selected: true};
    });
  grid.from = query.from;
  grid.values = query.select
    .filter(col => col.includes("."))
    .map(col => {
      return {name: col.replace(/\..*$/, ""), selected: true};
    });
  grid.fields.forEach(field => {
    field.selected = query.select.includes(field.name) ||
      query.select.includes(field.name + ".SUM") ||
      where.find(condition => field.name in condition);
  });
  grid.filters = where.map((condition) => {
    const columnName = Object.keys(condition)[0];
    return {name: columnName, selected: true, selectedValues: condition[columnName]["$in"]};
  });
  grid.where = where;
  grid.referenceCcy = query["with"]["FX"]["currency"][0];
}


export async function clearTable(grid) {
  grid.excelTiming = performance.now();
  grid.serverTiming = 0;
  grid.filters = [];
  grid.columns = [];
  grid.values = [];
  grid.where = [];
  grid.referenceCcy = "EUR";
  grid.filterColumn = {};
  grid.fields.forEach(field => {
    field.selectedValues = [];
    field.selected = false;
  });
  await Excel.run(async context => {
    const dataSheet = context.workbook.worksheets.getActiveWorksheet();
    dataSheet.tables.load("items");
    await context.sync();
    dataSheet.tables.items.forEach(table => table.delete());

    dataSheet.activate();
    await context.sync();
  }).catch(function (error) {
    console.log("Error: " + error);
    if (error instanceof OfficeExtension.Error) {
      console.log("Debug info: " + JSON.stringify(error.debugInfo));
    }
  });
  grid.excelTiming = performance.now() - grid.excelTiming;
}

export async function execute(grid) {
  grid.serverTiming = performance.now();
  const select = [];
  grid.columns.forEach(f => select.push(f.name));
  grid.values.forEach(v => select.push(v.name + ".SUM"));
  const retainedNames = grid.filters.map(col => col.name);
  const finalWhere = grid.where.filter(c => {
    return retainedNames.some(name => name in c);
  });
  const request = {
    select: select,
    from: grid.dataset,
    where: finalWhere,
    with: {"FX": {"currency": [grid.referenceCcy]}}
  };
  console.log("executing query: " + JSON.stringify(request));
  await api.query(
    request,
    async data => {
      grid.serverTiming = performance.now() - grid.serverTiming;
      grid.excelTiming = performance.now();
      await Excel.run(async context => {
        // act only on data existence
        if (data !== undefined && data.length > 0) {
          // calculating the data table range
          const selectedRange = context.workbook.getSelectedRange();
          const dataSheet = context.workbook.worksheets.getActiveWorksheet();
          const header = Object.keys(data[0]);

          // check if overlap with existing Table
          let dataTable = dataSheet.tables.getItemOrNullObject(api.dataTableName);
          const existingRange = dataTable.getRange();
          const intersection = existingRange.getIntersectionOrNullObject(selectedRange);
          intersection.load("address");
          await context.sync();
          let start = selectedRange.getCell(0, 0);
          if (intersection.address != null) {
            // if overlap: keep the same range
            start = existingRange.getCell(0, 0);
          }

          // re-calculating the table range, ajusting the starting cell by moving 1 left
          const tableRange = start.getColumnsAfter(header.length).getOffsetRange(0, -1);

          // re-creating the table with header
          dataTable.delete();
          dataTable = dataSheet.tables.add(tableRange, true);
          dataTable.getHeaderRowRange().values = [header];
          dataTable.name = api.dataTableName;
          dataTable.showTotals = true;
          // adding data
          dataTable.rows.add(
            null,
            data.map(item => {
              const members = [];
              header.forEach(key => members.push(item[key]));
              return members;
            })
          );
          // auto fits
          dataSheet.getUsedRange().format.autofitColumns();
          dataSheet.getUsedRange().format.autofitRows();

          dataSheet.activate();
          await context.sync();
        } else {
          // remove table
          const dataSheet = context.workbook.worksheets.getActiveWorksheet();
          let dataTable = dataSheet.tables.getItemOrNullObject(api.dataTableName);
          dataTable.delete();
          // set no data
          const selectedRange = context.workbook.getSelectedRange();
          let cell = selectedRange.getCell(0, 0);
          cell.values = [["No Data .."]];
        }
      }).catch(function (error) {
        console.log("Error: " + error);
        if (error instanceof OfficeExtension.Error) {
          console.log("Detailed info: " + JSON.stringify(error.debugInfo));
        }
      });
      grid.excelTiming = performance.now() - grid.excelTiming;
    }
  );
}