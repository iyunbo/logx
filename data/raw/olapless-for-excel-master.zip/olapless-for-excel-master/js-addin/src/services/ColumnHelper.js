export function isNumeric(column) {
  return column.type === "double" || column.type === "integer";
}

export function addColumn(columns, column) {
  if (!columns.includes(column)) {
    column.selected = true;
    columns.push(column);
  }
}

export function removeColumn(columns, column) {
  if (columns.indexOf(column) > -1) {
    columns.splice(columns.indexOf(column), 1);
  }
}