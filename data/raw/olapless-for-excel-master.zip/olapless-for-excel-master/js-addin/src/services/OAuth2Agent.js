
const authorizationId = "github";

export const authorizationURL = window.location.origin + "/oauth2/authorization/" + authorizationId;

export function onLoginSuccess(asyncResult, grid, callback) {
  const dialog = asyncResult.value;
  dialog.addEventHandler(Office.EventType.DialogMessageReceived, function (arg) {
    dialog.close();
    const messageFromLogin = JSON.parse(arg.message);
    grid.username = messageFromLogin.username;
    callback(grid);
  });
}