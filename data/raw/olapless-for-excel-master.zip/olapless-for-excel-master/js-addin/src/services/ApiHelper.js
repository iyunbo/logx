export const dataTableName = "OLAPLESS";

function getCookie(name) {
  if (!document.cookie) {
    return null;
  }

  const xsrfCookies = document.cookie.split(";")
    .map(c => c.trim())
    .filter(c => c.startsWith(name + "="));

  if (xsrfCookies.length === 0) {
    return null;
  }
  return decodeURIComponent(xsrfCookies[0].split("=")[1]);
}

export function discovery(callback) {
  fetch("/data/discovery")
    .then(response => response.json())
    .then(callback)
    .catch(error => console.error(error));
}

function execute(request, callback) {
  const csrfToken = getCookie("CSRF-TOKEN");
  // Angular uses XSRF instead of CSRF: https://spring.io/guides/tutorials/spring-boot-oauth2/
  const xsrfToken = getCookie("XSRF-TOKEN");
  const headers = new Headers({
    "Content-Type": "application/json",
    "X-CSRF-TOKEN": csrfToken,
    "X-XSRF-TOKEN": xsrfToken
  });
  fetch("/data/query", {
    method: "POST",
    headers,
    body: JSON.stringify(request)
  })
    .then(response => response.json())
    .then(callback)
    .catch(error => console.error(error));
}

export function query(request, callback) {
  execute(request, callback);
}

export function values(column, dataset, callback) {
  execute({
    select: [column],
    from: dataset,
    where: [],
    with: {}
  }, callback);
}

export function bookmarks(callback) {
  fetch("/data/bookmarks")
    .then(response => response.json())
    .then(callback)
    .catch(error => console.error(error));
}
