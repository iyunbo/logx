/* eslint-disable */
<template>
  <div id="app">
    <tabs ref="tabs">
      <tab name="Connection">
        <login-logout :grid="grid" :login="login" :logout="logout"/>
      </tab>
      <tab name="Bookmarks">
        <bookmarks-pane :grid="grid" :on-select-bookmark="chooseBookmark"/>
      </tab>
      <tab name="Analysis" ref="analysis" :selected="true">
        <data-table ref="datatable" :grid="grid"/>
      </tab>
    </tabs>
  </div>
</template>

<script>
  import DataTable from "./components/DataTable";
  import loginLogout from "./components/LoginLogout";
  import Tabs from "./components/Tabs";
  import Tab from "./components/Tab";
  import BookmarksPane from "./components/BookmarksPane";
  import * as oauth2 from "./services/OAuth2Agent";
  import * as gridManager from "./services/GridManager";

  export default {
    name: "App",
    components: {DataTable, BookmarksPane, loginLogout, Tab, Tabs},
    data() {
      return {
        query: {},
        grid: gridManager.empty,
      };
    },
    methods: {
      login() {
        // to avoid messing with 'this', see issue: https://michaelnthiessen.com/this-is-undefined/
        const g = this.$refs.datatable.grid;
        Office.context.ui.displayDialogAsync(
          oauth2.authorizationURL,
          {
            height: 40,
            width: 16,
            promptBeforeOpen: false
          },
          asyncResult => {
            oauth2.onLoginSuccess(asyncResult, g, gridManager.init);
            this.$refs.tabs.selectTab(this.$refs.analysis);
          }
        );
        g.authenticated = true;
      },
      async logout() {
        const g = this.$refs.datatable.grid;
        g.authenticated = false;
        await gridManager.clearAll(g);
      },
      chooseBookmark(bookmark) {
        this.query = bookmark.query;
        this.$refs.tabs.selectTab(this.$refs.analysis);
        this.$refs.datatable.setBookmark(bookmark);
      }
    }
  };
</script>

<style>
  .content-header {
    background: #2a8dd4;
    color: #fff;
    position: absolute;
    top: 35px;
    left: 0;
    width: 100%;
    height: 50px;
    overflow: hidden;
  }

  .content-main {
    background: #fff;
    position: absolute;
    top: 85px;
    left: 0;
    right: 0;
    bottom: 0;
    overflow: auto;
  }

  .header h1 {
    padding-left: 15px;
    margin-top: 5px;
  }

  .padding {
    padding: 15px;
  }

  .primary-btn {
    height: 35px;
    width: 100px;
    color: white;
    border-radius: 4px;
    background: #2a8dd4;
    cursor: pointer;
    margin-left: 10px;
    margin-right: 10px;
  }

  .search_bar {
    width: 140px;
    margin-bottom: 5px;
  }

  .drag,
  .drop {
    display: inline-block;
    padding: 1px;
    vertical-align: top;
    width: auto;
  }

  .drag {
    cursor: move;
  }

  .drop {
    border: 1px groove;
  }

  .small-font {
    text-align: center;
    font-size: 10px;
  }

  .login {
    width: 96%;
    text-align: right;
    color: #0074D9;
  }

  .performance {
    color: #7f7f7f;
  }

  .footer {
    width: 80%;
    padding: 0 10px 10px 10px;
  }

  .authenticated {
    color: #2a8dd4;
  }

  .disconnected {
    color: #aa0000;
  }
</style>

