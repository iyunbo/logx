<template>
  <div class="padding">
    <div class="content-header">
      <div class="header">
        <h1>connection</h1>
      </div>
    </div>
    <div class="content-main">
      <div class="padding center">
        <user-profile :grid="grid"/>
        <div class="padding authenticated" v-show="grid.authenticated">You are currently connected</div>
        <div class="padding disconnected" v-show="!grid.authenticated">You are now disconnected</div>
        <div class="padding">
          <button class="primary-btn" @click="logout" v-show="grid.authenticated">
            <font-awesome-icon :icon="['fas', 'sign-out-alt']"/>
            Logout
          </button>
          <button class="primary-btn" @click="login" v-show="!grid.authenticated">
            <font-awesome-icon :icon="['fas', 'sign-in-alt']"/>
            Login
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import UserProfile from "./UserProfile";
  import {library} from "@fortawesome/fontawesome-svg-core";
  import {FontAwesomeIcon} from "@fortawesome/vue-fontawesome";
  import {faSignInAlt, faSignOutAlt} from "@fortawesome/free-solid-svg-icons";

  library.add(faSignInAlt, faSignOutAlt);

  export default {
    components: {FontAwesomeIcon, UserProfile},
    name: "LoginPane",
    props: {
      grid: {
        type: Object,
        required: true
      },
      login: {
        type: Function,
        default: () => {
          console.log("login succeed");
        }
      },
      logout: {
        type: Function,
        default: () => {
          console.log("logout now");
        }
      }
    },
    data() {
      return {
        action: "Logout"
      };
    },
    methods: {},
    mounted() {
      this.login();
    }
  };
</script>

<style scoped>
  .center {
    text-align: center;
  }
</style>