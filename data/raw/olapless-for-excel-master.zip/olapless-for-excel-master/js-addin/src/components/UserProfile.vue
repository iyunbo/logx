<template>
  <div class="login small-font" :class="authClass">
    <font-awesome-icon :icon="['fas', 'user']"/>
    {{ grid.username }}
    <label v-show="!grid.authenticated"> Disconnected</label>
  </div>
</template>

<script>
  import {library} from "@fortawesome/fontawesome-svg-core";
  import {FontAwesomeIcon} from "@fortawesome/vue-fontawesome";
  import {faUser} from "@fortawesome/free-solid-svg-icons";

  library.add(faUser);

  export default {
    name: "UserProfile",
    components: {FontAwesomeIcon},
    props: {
      grid: {
        type: Object,
        required: true
      }
    },
    data() {
      return {};
    },
    computed: {
      authClass() {
        return this.grid.authenticated ? "authenticated" : "disconnected";
      }
    },
    mounted() {
    }
  };
</script>

<style scoped>
</style>