<template>
  <div>
    <div class="content-header">
      <div class="header">
        <h1>bookmarks</h1>
      </div>
    </div>
    <div class="content-main">
      <div class="padding">
        <user-profile :grid="grid"/>
        <br>
        <input class="search_bar" type="text" v-model="search_filter" placeholder=" search bookmarks ..."
               :style="{ width: width + 'px',}">
        <div
          :style="{ width: width + 'px', minHeight: height + 'px', maxHeight: height + 'px', overflowY: 'scroll' }"
          class="bookmark-table"
        >
          <div v-for="item in filtered" :key="item.name">
            <div @click="onSelectBookmark(item)" class="bookmark-item">
              <span :style="{paddingLeft: '10px', paddingRight: '10px'}"><font-awesome-icon
                :icon="['fas', 'book']"/></span>
              {{ item.name }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {library} from "@fortawesome/fontawesome-svg-core";
  import {FontAwesomeIcon} from "@fortawesome/vue-fontawesome";
  import {faBook} from "@fortawesome/free-solid-svg-icons";
  import UserProfile from "./UserProfile";

  library.add(faBook);

  export default {
    components: {FontAwesomeIcon, UserProfile},
    name: "BookmarksPane",
    props: {
      grid: {
        type: Object,
        required: true
      },
      height: {
        default: "560",
        type: String
      },
      width: {
        default: "300",
        type: String
      },
      onSelectBookmark: {
        type: Function,
        default: (item) => {
          console.log("check bookmark: " + item.name);
        }
      }
    },
    data() {
      return {
        search_filter: "",
      };
    },
    mounted() {
    },
    methods: {},
    computed: {
      filtered() {
        return this.grid.bookmarks.filter(col => {
          return col.name
            .toLowerCase()
            .includes(this.search_filter.toLowerCase());
        });
      }
    }
  };
</script>

<style scoped>
  .bookmark-table {
    border: 1px groove;
  }

  .bookmark-item {
    cursor: pointer;
  }
</style>