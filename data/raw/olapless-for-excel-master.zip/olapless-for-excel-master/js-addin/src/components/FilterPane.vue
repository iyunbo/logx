<template>
  <div>
    <p>
      <font-awesome-icon :icon="['fas', 'filter']"/>
      <span>{{ title }}</span>
    </p>
    <drop class="drop" @drop="handleDrop">
      <div
        :style="{ width: width + 'px', minHeight: height + 'px', maxHeight: height + 'px', overflowY: 'scroll' }"
      >
        <div v-for="column in columns" :key="column.name" @click="afterDrop(column)" :style="{cursor: 'pointer'}">
          <span>
            <font-awesome-icon :icon="['fas', 'filter']" size="xs"/>
          </span>
          <drag class="drag" :transfer-data="{ item: column, list: columns }">{{ column.name }}
            {{ "(" + column.selectedValues.length + " selected)" }}
          </drag>
        </div>
      </div>
    </drop>
  </div>
</template>

<script>
  import {Drag, Drop} from "vue-drag-drop";
  import * as columnHelper from "../services/ColumnHelper.js";
  import {library} from "@fortawesome/fontawesome-svg-core";
  import {FontAwesomeIcon} from "@fortawesome/vue-fontawesome";
  import {faFilter} from "@fortawesome/free-solid-svg-icons";

  library.add(faFilter);

  export default {
    components: {Drag, Drop, FontAwesomeIcon, library, faFilter},
    name: "FilterPane",
    props: {
      columns: {
        type: Array,
        required: true
      },
      width: {
        default: "300",
        type: String
      },
      height: {
        default: "130",
        type: String
      },
      title: {
        type: String,
        required: true
      },
      afterDrop: {
        type: Function,
        default: (column) => {
          console.log("column selected: " + column);
        }
      }
    },
    data() {
      return {
        selected: [],
        showModal: false
      };
    },
    methods: {
      handleDrop(data) {
        const item = data.item;
        if (!columnHelper.isNumeric(item)) {
          columnHelper.addColumn(this.columns, item);
          this.afterDrop(item);
        }
      }
    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
