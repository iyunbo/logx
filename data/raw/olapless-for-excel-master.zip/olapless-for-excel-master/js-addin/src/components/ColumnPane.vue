<template>
  <div>
    <p>
      <font-awesome-icon :icon="['fas', 'columns']"/>
      <span>{{ title }}</span>
    </p>
    <drop class="drop" @drop="handleDrop">
      <div :style="{ width: width + 'px', minHeight: height + 'px', maxHeight: height + 'px', overflowY: 'scroll' }">
        <div v-for="column in columns" :key="column.name">
          <input type="checkbox" v-model="column.selected" :disabled="true" @change="check(column, $event)">
          <drag
            class="drag"
            :transfer-data="{ item: column, list: columns, fromColumnOrRow: true }"
          >{{ column.name }}
          </drag>
        </div>
      </div>
    </drop>
  </div>
</template>

<script>
  import {Drag, Drop} from "vue-drag-drop";
  import * as columnHelper from "../services/ColumnHelper.js";
  import {library} from "@fortawesome/fontawesome-svg-core";
  import {FontAwesomeIcon} from "@fortawesome/vue-fontawesome";
  import {faColumns} from "@fortawesome/free-solid-svg-icons";

  library.add(faColumns);

  export default {
    components: {Drag, Drop, FontAwesomeIcon},
    name: "ColumnPane",
    props: {
      columns: {
        type: Array,
        required: true
      },
      width: {
        default: "140",
        type: String
      },
      height: {
        default: "130",
        type: String
      },
      title: {
        type: String,
        required: true
      }
    },
    data() {
      return {
        selected: [],
      };
    },
    methods: {
      handleDrop(data, event) {
        const item = data.item;
        const list = data.list;
        // only treat non numeric dimensions
        if (columnHelper.isNumeric(item)) {
          return;
        }
        // remove only if from rows or columns
        if (data.fromColumnOrRow) {
          columnHelper.removeColumn(list, item);
        }
        columnHelper.addColumn(this.columns, item);
      }
    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
