<template>
  <div>
    <div class="content-header">
      <div class="header">
        <h1>{{ grid.dataset }}</h1>
      </div>
    </div>
    <div class="content-main">
      <div class="padding">
        <user-profile :grid="grid"/>
        <FieldPane
          :items="grid.fields"
          :height="'180'"
          :check="onSelection"
        />
        <table style="width:100%">
          <tr>
            <td>
              <ColumnPane :columns="grid.columns" :title="'Columns'"/>
            </td>
            <td>
              <ValuePane :columns="grid.values" :title="'Values'"/>
            </td>
          </tr>
        </table>
        <FilterPane :columns="grid.filters" :title="'Filters'" :after-drop="(column) => {
          this.grid.showModal = true;
          this.grid.filterColumn = column;
        }"/>
        <br>
        <ForexSelection :currencies="grid.currencies" :title="'Currency'" :on-currency="(ccy) => {
          this.grid.referenceCcy = ccy;
        }" :selected="grid.referenceCcy"/>
        <br>
        <table style="width:100%">
          <tr>
            <td>
              <button class="primary-btn" @click="clearQuery">
                <font-awesome-icon :icon="['fas', 'recycle']"/>
              </button>
            </td>
            <td>
              <button class="primary-btn" @click="executeQuery">
                <font-awesome-icon :icon="['fas', 'play']"/>
              </button>
            </td>
          </tr>
        </table>
        <br>
        <p class="small-font">Data table will be displayed at your selected cells</p>
      </div>
      <table class="footer">
        <tr>
          <td class="performance small-font">
            <font-awesome-icon :icon="['fas', 'server']"/>
            server: {{ (grid.serverTiming / 1000).toFixed(3) }} seconds
          </td>
          <td class="performance small-font">
            <font-awesome-icon :icon="['fas', 'table']"/>
            Excel: {{ (grid.excelTiming / 1000).toFixed(3) }} seconds
          </td>
        </tr>
      </table>
      <FilterSelection v-if="grid.showModal" :column="grid.filterColumn" :dataset="grid.dataset"
                       @selected-values="onSelectedValues"/>
    </div>
  </div>
</template>

<script>
  import FieldPane from "./FieldPane";
  import ColumnPane from "./ColumnPane";
  import ValuePane from "./ValuePane";
  import FilterPane from "./FilterPane";
  import FilterSelection from "./FilterSelection";
  import ForexSelection from "./ForexSelection";
  import UserProfile from "./UserProfile";
  import * as gridManager from "../services/GridManager.js";
  import {library} from "@fortawesome/fontawesome-svg-core";
  import {FontAwesomeIcon} from "@fortawesome/vue-fontawesome";
  import {faPlay, faRecycle, faServer, faTable} from "@fortawesome/free-solid-svg-icons";

  library.add(faPlay, faRecycle, faServer, faTable);

  export default {
    name: "DataTable",
    components: {FieldPane, ColumnPane, ValuePane, FilterPane, UserProfile, FilterSelection, FontAwesomeIcon, ForexSelection},
    props: {
      grid: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
      };
    },
    mounted() {
    },
    methods: {
      async clearQuery() {
        await gridManager.clearTable(this.grid);
      },
      setBookmark(bookmark) {
        gridManager.loadBookmark(bookmark, this.grid);
      },
      onSelection(column) {
        gridManager.selectField(column, this.grid);
      },
      onSelectedValues(column) {
        gridManager.selectValue(column, this.grid);
      },
      async executeQuery() {
        await gridManager.execute(this.grid);
      }
    }
  };
</script>

<style scoped>
</style>