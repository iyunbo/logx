<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">

          <div class="modal-header">
            <slot name="header">
              <h4 slot="header">Select values for {{ column.name }}</h4>
            </slot>
          </div>

          <div class="modal-body">
            <slot name="body"/>
            <FieldPane
              :items="values"
              :height="'160'"
              :width="'240'"
              :check="onSelection"
              :show-tips="false"
            />
          </div>

          <div class="modal-footer">
            <slot name="footer">
              {{ this.column.selectedValues.length > 2 ? this.column.selectedValues.length : this.column.selectedValues
              }} selected
              <button class="modal-default-button" @click="submitValues()">
                Submit
              </button>
            </slot>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>
<script>
  import FieldPane from "./FieldPane";
  import * as api from "../services/ApiHelper.js";

  export default {
    name: "FilterSelection",
    components: {FieldPane},
    props: {
      column: {
        type: Object,
        required: true
      },
      dataset: {
        type: String,
        required: true
      }
    },
    mounted() {
      api.values(this.column.name, this.dataset, data => {
        const all = data.map(line => line[this.column.name]);
        this.values = [...new Set(all)].map(value => {
          return {name: value, selected: this.column.selectedValues.includes(value)};
        });
      });
    },
    data() {
      return {
        values: []
      };
    },
    methods: {
      onSelection(item) {
        if (item.selected) {
          if (!this.column.selectedValues.includes(item.name)) {
            this.column.selectedValues.push(item.name);
          }
        } else {
          const index = this.column.selectedValues.indexOf(item.name);
          if (index > -1) {
            this.column.selectedValues.splice(index, 1);
          }
        }
      },
      submitValues() {
        this.$emit("selected-values", this.column);
      }
    }
  };
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .modal-mask {
    position: fixed;
    z-index: 9998;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: table;
    transition: opacity 0.3s ease;
  }

  .modal-wrapper {
    display: table-cell;
    vertical-align: middle;
  }

  .modal-container {
    width: 240px;
    margin: 0 auto;
    padding: 20px 20px;
    background-color: #fff;
    border-radius: 2px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.33);
    transition: all 0.3s ease;
    font-family: Helvetica, Arial, sans-serif;
  }

  .modal-header h3 {
    margin-top: 0;
    color: #42b983;
  }

  .modal-body {
    margin: 20px 0;
  }

  .modal-default-button {
    float: right;
    color: white;
    border-radius: 2px;
    background: #2a8dd4;
  }

  /*
   * The following styles are auto-applied to elements with
   * transition="modal" when their visibility is toggled
   * by Vue.js.
   *
   * You can easily play with the modal transition by editing
   * these styles.
   */

  .modal-enter {
    opacity: 0;
  }

  .modal-leave-active {
    opacity: 0;
  }

  .modal-enter .modal-container,
  .modal-leave-active .modal-container {
    -webkit-transform: scale(1.1);
    transform: scale(1.1);
  }
</style>