<template>
  <div>
    <div class="tabs">
      <ul>
        <li v-for="tab in tabs" :key="tab.name" :class="{ 'is-active': tab.isActive }">
          <a :href="tab.href" @click="selectTab(tab)" :class="{ 'is-active': tab.isActive }">{{ tab.name }}</a>
        </li>
      </ul>
    </div>
    <div class="tabs-details">
      <slot/>
    </div>
  </div>
</template>

<script>
  export default {
    name: "Tabs",
    data() {
      return {tabs: []};
    },

    created() {

      this.tabs = this.$children;

    },
    methods: {
      selectTab(selectedTab) {
        this.tabs.forEach(tab => {
          tab.isActive = (tab.name === selectedTab.name);
        });
      }
    }
  };
</script>

<style scoped>
  .tabs {
    background: #2a8dd4;
    color: #fff;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 35px;
    overflow: hidden;
    margin-top: 0;
    padding-top: 0;
  }

  li {
    float: right;
    margin-right: 40px;
    font-size: 9px;
    color: white;
    list-style-type: none;
  }

  li a.is-active {
    color: #2d2d2d;
  }

  li a {
    color: white;
  }
</style>