<template>
  <div :style="{ width: width + 'px' }">
    <table style="width:100%">
      <tr>
        <td><font-awesome-icon :icon="['fas', 'euro-sign']"/></td>
        <td>{{ title }}</td>
        <td/>
        <td>
          <label>
            <select v-model="selected" @change="onCurrency(selected)">
              <option disabled :value="''">Please select one</option>
              <option v-for="ccy in currencies" :value="ccy" :key="ccy">{{ ccy }}</option>
            </select>
          </label>
        </td>
      </tr>
    </table>
  </div>
</template>

<script>
  import {library} from "@fortawesome/fontawesome-svg-core";
  import {FontAwesomeIcon} from "@fortawesome/vue-fontawesome";
  import {faEuroSign} from "@fortawesome/free-solid-svg-icons";

  library.add(faEuroSign);

  export default {
    components: {FontAwesomeIcon},
    name: "ForexSelection",
    props: {
      currencies: {
        type: Array,
        required: true
      },
      width: {
        default: "200",
        type: String
      },
      title: {
        type: String,
        required: true
      },
      onCurrency: {
        type: Function,
        default: (selected) => {
          console.log("selected: " + selected);
        }
      },
      selected: {
        type: String,
        default: "EUR"
      }
    },
    data() {
      return {
      };
    },
    methods: {}
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
