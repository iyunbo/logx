<template>
  <div>
    <p v-show="showTips">
      <span><font-awesome-icon :icon="['fas', 'bars']"/></span>
      <span>Check</span>
      <span><font-awesome-icon :icon="['fas', 'check']"/></span>
      <span>or Drag&Drop</span>
      <span><font-awesome-icon :icon="['fas', 'mouse']"/></span>
    </p>
    <input class="search_bar" type="text" v-model="search_filter" placeholder=" search fields ..."
           :style="{ width: width + 'px',}">
    <drop class="drop" @drop="handleDrop">
      <div
        :style="{ width: width + 'px', minHeight: height + 'px', maxHeight: height + 'px', overflowY: 'scroll' }"
      >
        <div v-for="item in filtered" :key="item.name">
          <input type="checkbox" v-model="item.selected" @change="check(item, $event)">
          <drag
            class="drag"
            :transfer-data="{ item: item, list: items }"
          >{{ item.name }}
          </drag>
        </div>
      </div>
    </drop>
  </div>
</template>

<script>
  import {Drag, Drop} from "vue-drag-drop";
  import * as columnHelper from "../services/ColumnHelper.js";
  import {library} from "@fortawesome/fontawesome-svg-core";
  import {FontAwesomeIcon} from "@fortawesome/vue-fontawesome";
  import {faBars, faCheck, faMouse} from "@fortawesome/free-solid-svg-icons";

  library.add(faBars, faCheck, faMouse);

  export default {
    components: {Drag, Drop, FontAwesomeIcon},
    name: "FieldPane",
    props: {
      items: {
        type: Array,
        required: true
      },
      height: {
        default: "160",
        type: String
      },
      width: {
        default: "300",
        type: String
      },
      check: {
        type: Function,
        default: () => {
        }
      },
      showTips: {
        type: Boolean,
        default: true
      }
    },
    data() {
      return {
        search_filter: ""
      };
    },
    methods: {
      handleDrop(data) {
        const item = data.item;
        const list = data.list;
        if (list !== this.items) {
          item.selectedValues = [];
          columnHelper.removeColumn(list, item);
          columnHelper.addColumn(this.items, item);
        }
      },
    },
    computed: {
      filtered() {
        return this.items.filter(col => {
          return col.name
            .toLowerCase()
            .includes(this.search_filter.toLowerCase());
        });
      }
    }
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
