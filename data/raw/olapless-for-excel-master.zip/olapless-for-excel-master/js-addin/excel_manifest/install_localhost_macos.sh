# https://docs.microsoft.com/en-us/office/dev/add-ins/testing/sideload-an-office-add-in-on-ipad-and-mac

cp manifest.xml /Users/b/Library/Containers/com.microsoft.Excel/Data/Documents/wef/manifest.xml
