package io.olapless.for_excel.springboot.service;

import static io.olapless.for_excel.springboot.dto.Condition.in;
import static io.olapless.for_excel.springboot.dto.Condition.notIn;
import static io.olapless.for_excel.springboot.dto.Filter.and;
import static io.olapless.for_excel.springboot.dto.Filter.when;

import java.util.List;
import java.util.Map;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;

import io.olapless.for_excel.springboot.dto.Bookmark;
import io.olapless.for_excel.springboot.dto.Dataset;
import io.olapless.for_excel.springboot.dto.Metadata;
import io.olapless.for_excel.springboot.dto.QueryRequest;
import io.olapless.for_excel.springboot.dto.QueryResponse;

public class TestDummyDataAccessManager {

	private DummyDataAccessManager dataAccessManager = new DummyDataAccessManager();

	@Test
	public void test_query() {
		QueryRequest request = QueryRequest.Builder.request()
				.select("Continent", "Country", "import.SUM", "export.SUM")
				.from("WorldStats")
				.where(when("Continent", in("Europe", "Asia")), and("Country", notIn("Spain", "Italy", "China")))
				.build();

		QueryResponse response = dataAccessManager.query(request);

		Assertions.assertThat(response).hasSize(3);
		Assertions.assertThat(response.get(0)).containsValues("Asia", "Japan", 1402.5, 2261.0);
		Assertions.assertThat(response.get(1)).containsValues("Europe", "France", 3146.5, 5007.500000000001);
		Assertions.assertThat(response.get(2)).containsValues("Asia", "Korea", 2002.15, 3261.0);

	}

	@Test
	public void test_discovery() {
		Metadata metadata = dataAccessManager.discovery();

		Assertions.assertThat(metadata.getDatasets()).hasSize(1);
		Dataset dataset = metadata.getDatasets().get(0);
		Assertions.assertThat(dataset.getId()).isEqualTo("worldstats");
		Assertions.assertThat(dataset.getColumns()).containsKeys("Continent", "Country", "Company", "import", "export");
		Assertions.assertThat(metadata.getAggregators()).contains("$sum", "$max", "$min", "$avg", "$count");
	}

	@Test
	public void should_convert_number_according_to_ccy() {
		Map<String, Object> map = dataAccessManager.convertCcy(ImmutableMap.of("import", 100), Currency.USD);
		Assertions.assertThat(map).containsValue(108d);

		map = dataAccessManager.convertCcy(ImmutableMap.of("import", 100), Currency.EUR);
		Assertions.assertThat(map).containsValue(100d);
	}

	@Test
	public void should_not_convert_non_number() {
		Map<String, Object> map = dataAccessManager.convertCcy(ImmutableMap.of("Country", "France"), Currency.USD);
		Assertions.assertThat(map).containsValue("France");
	}

	@Test
	public void test_bookmarks_retrieve() {
		List<Bookmark> bookmarks = dataAccessManager.getBookmarks();
		Assertions.assertThat(bookmarks).hasSize(3);
		Assertions.assertThat(bookmarks.get(0).getName()).isEqualTo("bookmark-import-amount");
	}
}
