package io.olapless.exe;

import io.olapless.for_excel.springboot.RunJsAddinBackend;

public class RunTestBackend extends RunJsAddinBackend {
}
