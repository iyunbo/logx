package io.olapless.for_excel.springboot.dto;

import static io.olapless.for_excel.springboot.dto.Condition.eq;
import static io.olapless.for_excel.springboot.dto.Condition.greaterThan;
import static io.olapless.for_excel.springboot.dto.Filter.and;
import static io.olapless.for_excel.springboot.dto.Filter.when;

import java.io.IOException;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;

public class TestQueryRequest {

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	public void should_convert_from_json() throws IOException {
		QueryRequest request =
				mapper.readValue(new ClassPathResource("sample/request.json").getFile(), QueryRequest.class);
		Assertions.assertThat(request.getFrom()).isEqualTo("WorldStats");
		Assertions.assertThat(request.getSelect()).contains("Continent", "import.SUM");
		Assertions.assertThat(request.getWith()).containsKeys("Date", "FX");
		Assertions.assertThat(request.getWhere()).hasSize(3);
		Assertions.assertThat(request.getWhere().get(0))
				.containsOnlyKeys("Continent")
				.containsValue(Condition.in("Europe", "Asia"));
	}

	@Test
	public void should_create_serializable_request() throws IOException {
		QueryRequest request = QueryRequest.Builder.request()
				.select("BaseCcy", "TargetCcy", "rate.SUM")
				.from("ForexPivot")
				.where(when("Source", eq("Euronext")), and("Date", greaterThan("2019-12-30")))
				.build();

		String json = mapper.writeValueAsString(request);

		QueryRequest deserilized = mapper.readValue(json, QueryRequest.class);

		Assertions.assertThat(deserilized).isEqualTo(request);
	}

}
