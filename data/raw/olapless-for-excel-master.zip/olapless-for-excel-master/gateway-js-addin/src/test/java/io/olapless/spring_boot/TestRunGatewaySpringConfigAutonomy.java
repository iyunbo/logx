package io.olapless.spring_boot;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.servlet.handler.HandlerMappingIntrospector;

import com.fasterxml.jackson.databind.ObjectMapper;

import cormoran.pepper.time.PepperDateHelper;
import io.olapless.for_excel.springboot.OlaplessForExcelSpringConfig;
import io.olapless.spring_boot.TestRunGatewaySpringConfigAutonomy.RunAgileaSpringConfigComplement;

@SpringBootTest
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { OlaplessForExcelSpringConfig.class,
		OlaplessForExcelH2TestSpringConfig.class,
		RunAgileaSpringConfigComplement.class })
@ActiveProfiles({ "h2" })
@TestPropertySource(locations = { "classpath:/h2.test.properties" })
public class TestRunGatewaySpringConfigAutonomy {

	protected static final Logger LOGGER = LoggerFactory.getLogger(TestRunGatewaySpringConfigAutonomy.class);

	@Configuration
	@Import(OlaplessForExcelH2TestSpringConfig.class)
	public static class RunAgileaSpringConfigComplement {

		// Required by CorsConfigurer as one of SpringMVC or SpringSecurity is not configured
		@Bean
		public HandlerMappingIntrospector mvcHandlerMappingIntrospector() {
			return new HandlerMappingIntrospector();
		}

		@Bean
		public ObjectMapper objectMapper() {
			return new ObjectMapper();
		}
	}

	@Autowired
	ApplicationContext appContext;

	@Test
	public void testAutonomy() {
		LOGGER.debug("Started on {}", PepperDateHelper.now());
	}

}
