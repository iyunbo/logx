package io.olapless.spring_boot;

import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * Provides a {@link DataSource} for unit-tests, based on H2
 * 
 * @author Benoit Lacelle
 *
 */
@Configuration
@Profile("h2")
public class OlaplessForExcelH2TestSpringConfig {
	private static final Logger LOGGER = LoggerFactory.getLogger(OlaplessForExcelH2TestSpringConfig.class);

	@Bean
	public DataSource dataSource(Environment env) throws SQLException {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("jdbc.driverClassName"));
		dataSource.setUrl(env.getProperty("jdbc.url"));
		dataSource.setUsername(env.getProperty("jdbc.user"));
		dataSource.setPassword(env.getProperty("jdbc.pass"));

		// Ensure the tables are initialized very soon in the ApplicationContext
		initTables(dataSource);

		return dataSource;
	}

	@Bean
	public Void initTables(DataSource dataSource) throws SQLException {
		Class<?> classObject;
		try {
			classObject = Class.forName("eu.agilea.pgsql.AgileaJdbcModelization");
		} catch (ClassNotFoundException e) {
			LOGGER.warn("Can not execute AgileaJdbcModelization.initTables as class is not available: {}",
					e.getClass().getSimpleName());
			return null;
		}

		try {
			classObject.getMethod("initTables", DataSource.class).invoke(null, dataSource);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException
				| SecurityException e) {
			LOGGER.warn("Can not execute AgileaJdbcModelization.initTables as method failed: {}",
					e.getClass().getSimpleName());
			return null;
		}
		return null;
	}
}
