package io.olapless.for_excel.springboot.dto;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;

public class MetadataTest {

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	public void should_convert_json_to_metadata() throws IOException {

		Metadata metadata = mapper.readValue(new ClassPathResource("sample/discovery.json").getFile(), Metadata.class);
		Assertions.assertThat(metadata.getDatasets()).hasSize(2);
		Dataset dataset = metadata.getDatasets().get(0);
		Assertions.assertThat(dataset.getId()).isEqualTo("dataset1");
		Assertions.assertThat(dataset.getColumns()).containsKeys("Continent", "Year", "Weekend", "import", "export");
		Assertions.assertThat(metadata.getAggregators()).contains("$sum", "$max", "$min", "$avg", "$count");
	}

	@Test
	public void should_convert_metadata_to_json() throws IOException {

		Metadata metadata = new Metadata(Collections.singletonList(new Dataset("testDataset",
				ImmutableMap.of("column1", new ColumnDefinition("string"), "column2", new ColumnDefinition("double")))),
				Arrays.asList("count", "max"),
				Arrays.asList("EUR", "USD"));

		String jsonString = mapper.writeValueAsString(metadata);
		Assertions.assertThat(jsonString).contains("\"column1\":{\"type\":\"string\"}");
		Assertions.assertThat(jsonString).contains("\"currencies\":[\"EUR\",\"USD\"]");
	}
}