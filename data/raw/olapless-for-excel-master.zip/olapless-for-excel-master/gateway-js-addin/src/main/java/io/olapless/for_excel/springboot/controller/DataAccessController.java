package io.olapless.for_excel.springboot.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.olapless.for_excel.springboot.constant.IApiConstant;
import io.olapless.for_excel.springboot.dto.Bookmark;
import io.olapless.for_excel.springboot.dto.Metadata;
import io.olapless.for_excel.springboot.dto.QueryRequest;
import io.olapless.for_excel.springboot.dto.QueryResponse;
import io.olapless.for_excel.springboot.service.IDataAccessManager;

/**
 * The entry points for data access
 * 
 * @author Yunbo WANG
 */
@RequestMapping(IApiConstant.API_DATA_ACCESS)
@RestController
public class DataAccessController implements IApiConstant {

	private final IDataAccessManager dataAccessManager;

	public DataAccessController(final IDataAccessManager dataAccessManager) {
		this.dataAccessManager = dataAccessManager;
	}

	@PostMapping(IApiConstant.API_QUERY)
	public QueryResponse query(@RequestBody QueryRequest queryRequest) {
		return this.dataAccessManager.query(queryRequest);
	}

	@GetMapping(IApiConstant.API_DISCOVERY)
	public Metadata discovery() {
		return this.dataAccessManager.discovery();
	}

	@GetMapping(IApiConstant.API_BOOKMARKS)
	public List<Bookmark> getBookmarks() {
		return this.dataAccessManager.getBookmarks();
	}

}
