package io.olapless.for_excel.springboot;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.resource.EncodedResourceResolver;
import org.springframework.web.servlet.resource.PathResourceResolver;

import com.google.common.primitives.Ints;

/**
 * Defines how are delivered static resources, including icons, the VueJS app
 *
 * @author Benoit Lacelle
 *
 */
// https://stackoverflow.com/questions/24156490/how-to-set-content-length-in-spring-mvc-rest-for-json
@Configuration
public class OlaplessMvcConfigurer implements WebMvcConfigurer {

	@Autowired
	Environment env;

	public static final int DEFAULT_CACHEPERIOD_MINUTE = 10;

	/**
	 * controllers always produce application/json response even other type is asked (eg: xml/application)
	 *
	 * @param configurer
	 *            content negotiation configurer
	 */
	@Override
	public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
		configurer.ignoreAcceptHeader(true).defaultContentType(MediaType.APPLICATION_JSON);
	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")
				.allowedMethods(OlaplessForExcelCorsConfiguration.getAllowedMethods())
				.allowedHeaders(OlaplessForExcelCorsConfiguration.getAlloweHeaders())
				.exposedHeaders(OlaplessForExcelCorsConfiguration.getExposedHeaders())
				.allowedOrigins(OlaplessForExcelCorsConfiguration.getAllowedOrigins());
	}

	// /**
	// * Define CorsEndpointProperties for management endpoints<br/>
	// *
	// * @return properties for CORS configuration specific for managements endpoints.
	// */
	// @Primary
	// @Bean
	// public CorsEndpointProperties mitrustCorsEndpointProperties() {
	// var corsEndpointProperties = new CorsEndpointProperties();
	// corsEndpointProperties.setAllowedOrigins(List.of(OlaplessForExcelCorsConfiguration.getAllowedOrigins()));
	// corsEndpointProperties.setAllowedMethods(List.of(OlaplessForExcelCorsConfiguration.getAllowedMethods()));
	// corsEndpointProperties.setAllowedHeaders(List.of(OlaplessForExcelCorsConfiguration.getAlloweHeaders()));
	// corsEndpointProperties.setExposedHeaders(List.of(OlaplessForExcelCorsConfiguration.getExposedHeaders()));
	//
	// return corsEndpointProperties;
	// }

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		// Resources controlled by Spring Security has
		// "Cache-Control: must-revalidate". -> We override it with some value

		registry.addResourceHandler("/**")
				.addResourceLocations(
						// Static resources like images
						"classpath:/public/",
						// Managed by addin-js project
						"classpath:/react/")
				.setCachePeriod(Ints.saturatedCast(TimeUnit.MINUTES.toSeconds(DEFAULT_CACHEPERIOD_MINUTE)))
				// https://github.com/webjars/webjars-locator/issues/100
				.resourceChain(true)
				// http://www.baeldung.com/spring-mvc-static-resources
				.addResolver(new EncodedResourceResolver())
				.addResolver(new PathResourceResolver());
	}

}
