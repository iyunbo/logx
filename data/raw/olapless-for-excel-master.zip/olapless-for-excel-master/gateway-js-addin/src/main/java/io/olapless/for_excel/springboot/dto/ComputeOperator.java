package io.olapless.for_excel.springboot.dto;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * TODO: implement each Operator in a separated class
 *
 * @author Yunbo WANG
 */
public enum ComputeOperator {
	SUM("$sum"), MUL("$mul"), CONCAT("$concat"), FX("currency");

	private final String expression;

	ComputeOperator(final String expression) {
		this.expression = expression;
	}

	@JsonValue
	public String getExpression() {
		return expression;
	}
}
