package io.olapless.for_excel.springboot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import io.olapless.for_excel.springboot.logs.ApplicationLoggingHelper;

/**
 * Main Entry-point for the back-end
 * 
 * @author Benoit Lacelle
 *
 */
// https://stackoverflow.com/questions/40228036/how-to-turn-off-spring-security-in-spring-boot-applicationot
@SpringBootApplication(scanBasePackages = "noscan")
public class RunJsAddinBackend {
	protected static final Logger LOGGER = LoggerFactory.getLogger(RunJsAddinBackend.class);

	protected RunJsAddinBackend() {
		// hidden
	}

	public static void main(String[] args) {
		ApplicationLoggingHelper.configureLogger();

		ApplicationContext context = new RunJsAddinBackend().start(args);

		LOGGER.info("Started: {}", context);
	}

	public ConfigurableApplicationContext start(String... args) {
		List<Class<?>> sources = getSpringConfigurations(true);

		SpringApplication app = new SpringApplication(sources.toArray(new Class[0]));

		return app.run(args);
	}

	/**
	 * 
	 * @param withSwagger
	 *            unit-tests often does not like Swagger
	 * @return
	 */
	public List<Class<?>> getSpringConfigurations(boolean withSwagger) {
		List<Class<?>> sources = new ArrayList<>();

		// Main entry point
		sources.add(RunJsAddinBackend.class);

		sources.add(OlaplessForExcelSpringConfig.class);

		sources.add(OlaplessSecurityConfig.class);

		if (withSwagger) {
			// check https://root/swagger-ui.html
			sources.addAll(Arrays.asList(OlaplessForExcelSwaggerMvcConfigurer.class));
		}

		return sources;
	}

}
