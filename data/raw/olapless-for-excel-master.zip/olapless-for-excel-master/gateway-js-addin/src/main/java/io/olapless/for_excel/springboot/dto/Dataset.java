package io.olapless.for_excel.springboot.dto;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The structure definition of a dataset. A dataset contains its id and a list of {@link ColumnDefinition}
 *
 * @author Yunbo WANG
 */
public class Dataset {
	private String id;
	private Map<String, ColumnDefinition> columns;

	@JsonCreator
	public Dataset(@JsonProperty("id") String id, @JsonProperty("columns") Map<String, ColumnDefinition> columns) {
		this.id = id;
		this.columns = columns;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Map<String, ColumnDefinition> getColumns() {
		return columns;
	}

	public void setColumns(Map<String, ColumnDefinition> columns) {
		this.columns = columns;
	}

}
