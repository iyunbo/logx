package io.olapless.for_excel.springboot.dto;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;

/**
 * A condition defines a logical operation over some value or values.
 *
 * @author Yunbo WANG
 * @see io.olapless.for_excel.springboot.dto.LogicalOperator
 */
public final class Condition extends TreeMap<LogicalOperator, List<Object>> {

	private static final long serialVersionUID = -8189927161698086920L;

	public static Condition in(String... values) {
		final Condition condition = new Condition();
		condition.put(LogicalOperator.IN, Arrays.asList(values));
		return condition;
	}

	public static Condition eq(Object value) {
		final Condition condition = new Condition();
		condition.put(LogicalOperator.IN, Collections.singletonList(value));
		return condition;
	}

	public static Condition notIn(String... values) {
		final Condition condition = new Condition();
		condition.put(LogicalOperator.NOT, Arrays.asList(values));
		return condition;
	}

	public static Condition greaterThan(Object value) {
		final Condition condition = new Condition();
		condition.put(LogicalOperator.GT, Collections.singletonList(value));
		return condition;
	}

	public static Condition greaterOrEqual(Object value) {
		final Condition condition = new Condition();
		condition.put(LogicalOperator.GTE, Collections.singletonList(value));
		return condition;
	}

	public static Condition lesserThan(Object value) {
		final Condition condition = new Condition();
		condition.put(LogicalOperator.LT, Collections.singletonList(value));
		return condition;
	}

	public static Condition lesserOrEqual(Object value) {
		final Condition condition = new Condition();
		condition.put(LogicalOperator.LTE, Collections.singletonList(value));
		return condition;
	}

}
