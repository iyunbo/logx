package io.olapless.for_excel.springboot.constant;

/**
 * Various constants used in the API: should remain as stable as possible
 * 
 * @author Benoit Lacelle
 *
 */
public interface IApiConstant {

	String API_QUERY = "/query";

	String API_DATA_ACCESS = "/data";

	String API_DISCOVERY = "/discovery";

	String API_BOOKMARKS = "/bookmarks";
}