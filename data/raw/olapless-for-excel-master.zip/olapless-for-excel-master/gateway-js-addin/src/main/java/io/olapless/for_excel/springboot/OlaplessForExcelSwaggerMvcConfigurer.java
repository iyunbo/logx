package io.olapless.for_excel.springboot;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Defines how are delivered swagger static resources, especially swagger-ui.html
 * 
 * Should be at: <root>/swagger/swagger-ui.html
 * 
 * @author Benoit Lacelle
 *
 */
@EnableSwagger2
@PropertySource(value = "classpath:swagger.properties", ignoreResourceNotFound = true)
@Configuration
public class OlaplessForExcelSwaggerMvcConfigurer implements WebMvcConfigurer {

}