package io.olapless.for_excel.springboot.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The top level of the metadata structure, the metadata should not require any other information to retrieve.
 * <p>
 * This object should allow the the API client to retrieve the necessary information in order to accessing data further
 *
 * @author Yunbo WANG
 */
public class Metadata {
	private List<Dataset> datasets;
	private List<String> aggregators;
	private List<String> currencies;

	@JsonCreator
	public Metadata(@JsonProperty("datasets") List<Dataset> datasets,
			@JsonProperty("aggregators") List<String> aggregators,
			@JsonProperty("currencies") List<String> currencies) {
		this.datasets = datasets;
		this.aggregators = aggregators;
		this.currencies = currencies;
	}

	public List<Dataset> getDatasets() {
		return datasets;
	}

	public void setDatasets(List<Dataset> datasets) {
		this.datasets = datasets;
	}

	public List<String> getAggregators() {
		return aggregators;
	}

	public void setAggregators(List<String> aggregators) {
		this.aggregators = aggregators;
	}

	public List<String> getCurrencies() {
		return currencies;
	}

	public void setCurrencies(List<String> currencies) {
		this.currencies = currencies;
	}
}
