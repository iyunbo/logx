package io.olapless.for_excel.springboot.logs;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;

import cormoran.pepper.jvm.GCInspector;
import cormoran.pepper.thread.PepperExecutorsHelper;

/**
 * {@link UncaughtExceptionHandler} which simply redirects from syserr to SLF4J
 * 
 * @author Benoit Lacelle
 *
 */
public class LoggingUncaughtExceptionHandler implements UncaughtExceptionHandler, DisposableBean {
	private static final Logger LOGGER = LoggerFactory.getLogger(LoggingUncaughtExceptionHandler.class);

	private static final int HISTO_ROWS = 1024;

	final ExecutorService histoExecutor = PepperExecutorsHelper.newShrinkableFixedThreadPool(1, "HeapHisto");

	@Override
	public void uncaughtException(Thread t, Throwable e) {
		// java.lang.ThreadGroup.uncaughtException(Thread, Throwable)
		LOGGER.error("Exception in thread " + t.getName(), e);

		// We do not want to freeze the execution of the main thread to pump a heap histogram
		histoExecutor.execute(() -> {
			String heapHistogram = GCInspector.getHeapHistogramAsString(HISTO_ROWS);
			LOGGER.info("Heap histogram:{}{}", System.lineSeparator(), heapHistogram);
		});
	}

	@Override
	public void destroy() throws InterruptedException {
		histoExecutor.shutdown();
		histoExecutor.awaitTermination(1, TimeUnit.MINUTES);
	}

}
