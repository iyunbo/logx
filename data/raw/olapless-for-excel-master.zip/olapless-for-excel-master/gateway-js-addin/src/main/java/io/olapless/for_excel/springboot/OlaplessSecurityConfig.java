package io.olapless.for_excel.springboot;

import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;

/**
 * Simple security configuration for a OAuth2 authentication process
 *
 * @author Yunbo WANG
 */
public class OlaplessSecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests(
				a -> a.antMatchers("/error", "/static/**", "/index.html").permitAll().anyRequest().authenticated())
				.exceptionHandling(e -> e.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))
				.oauth2Login()
				.defaultSuccessUrl("/static/login.html", true);
		// activate csrf with cookies
		http.csrf(c -> c.csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()));
		// known issue: https://github.com/OfficeDev/office-js/issues/925
		http.headers().frameOptions().disable();

	}
}