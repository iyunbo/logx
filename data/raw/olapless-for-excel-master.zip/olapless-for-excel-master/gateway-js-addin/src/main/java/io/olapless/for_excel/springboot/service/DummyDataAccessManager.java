package io.olapless.for_excel.springboot.service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ResourceUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.olapless.for_excel.springboot.dto.Bookmark;
import io.olapless.for_excel.springboot.dto.Computation;
import io.olapless.for_excel.springboot.dto.ComputeOperator;
import io.olapless.for_excel.springboot.dto.Condition;
import io.olapless.for_excel.springboot.dto.Filter;
import io.olapless.for_excel.springboot.dto.Metadata;
import io.olapless.for_excel.springboot.dto.QueryRequest;
import io.olapless.for_excel.springboot.dto.QueryResponse;

/**
 * Dummy implementation for {@link IDataAccessManager}
 *
 * @author Benoit Lacelle
 */
public class DummyDataAccessManager implements IDataAccessManager {
	private static final Logger LOGGER = LoggerFactory.getLogger(DummyDataAccessManager.class);

	private static final String DATASET_ID = "worldstats";

	private final QueryResponse data;
	private final Metadata metadata;
	private final List<Bookmark> bookmarks;

	public DummyDataAccessManager() {

		final ObjectMapper mapper = new ObjectMapper();
		try {
			String path = "classpath:data/metadata.json";
			LOGGER.info("reading metadata from {}", path);
			metadata = mapper.readValue(ResourceUtils.getURL(path), Metadata.class);

			path = "classpath:data/" + metadata.getDatasets().get(0).getId() + ".json";
			LOGGER.info("loading data from {}", path);
			data = mapper.readValue(ResourceUtils.getURL(path), QueryResponse.class);

			path = "classpath:data/bookmarks.json";
			LOGGER.info("loading data from {}", path);
			bookmarks = mapper.readValue(ResourceUtils.getURL(path), new TypeReference<>() {
			});
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	@Override
	public QueryResponse query(QueryRequest request) {

		if (!DATASET_ID.equalsIgnoreCase(request.getFrom())) {
			throw new IllegalArgumentException("This dataset is not supported: " + request.getFrom());
		}

		final Currency referenceCcy = getReferenceCcy(request);

		Map<String, Object> initMap = getResultProjection(request.getSelect()).stream()
				.collect(Collectors.toMap(Function.identity(), e -> 0D));

		Map<List<String>, Map<String, Object>> grouped = this.data.stream()

				.filter(predict(request.getWhere()))

				.map(line -> project(request.getSelect(), line))

				.map(line -> convertCcy(line, referenceCcy))

				.collect(Collectors.groupingBy(l -> groupKeys(l, request.getSelect()),
						Collectors.reducing(initMap, this::reducingLine)));

		return QueryResponse.of(new ArrayList<>(grouped.values()));
	}

	protected Map<String, Object> convertCcy(Map<String, Object> line, Currency referenceCcy) {
		return line.entrySet()
				.stream()
				.map(e -> convertNumber(e, referenceCcy))
				.collect(Collectors.toMap(Entry::getKey, Entry::getValue));
	}

	private Entry<String, Object> convertNumber(Entry<String, Object> entry, Currency referenceCcy) {
		final Object value = entry.getValue();
		if (value instanceof Number) {
			return Map.entry(entry.getKey(), ((Number) value).doubleValue() * referenceCcy.getRate());
		}
		return Map.entry(entry.getKey(), entry.getValue());
	}

	private Currency getReferenceCcy(QueryRequest request) {
		String referenceCcy = Currency.getDefault().name();

		if (request.getWith() != null && !request.getWith().isEmpty()) {
			final Map<String, Computation> with = request.getWith();
			final Computation computation = with.get(ComputeOperator.FX.name());
			if (computation != null) {
				referenceCcy = computation.get(ComputeOperator.FX).get(0);
			} else {
				throw new IllegalArgumentException("Only FX is supported for with clause");
			}
		}
		return Currency.valueOf(referenceCcy);
	}

	private Map<String, Object> reducingLine(Map<String, Object> left, Map<String, Object> right) {
		Map<String, Object> result = new TreeMap<>();
		for (String column : left.keySet()) {
			Object leftValue = left.get(column);
			Object rightValue = right.get(column);
			if (leftValue instanceof String) {
				if (leftValue.equals(rightValue)) {
					result.put(column, leftValue);
				} else {
					throw new IllegalStateException("Should not reduce with different keys on " + column
							+ ", provided lines: "
							+ left
							+ " and "
							+ right);
				}
			} else if (leftValue instanceof Number) {
				Number leftNumber = (Number) leftValue;
				if (rightValue instanceof Number) {
					Number rightNumber = (Number) rightValue;
					result.put(column, leftNumber.doubleValue() + rightNumber.doubleValue());
				} else if (rightValue instanceof String) {
					result.put(column, rightValue);
				} else {
					throw new IllegalArgumentException("Unsupported type: " + rightValue.getClass());
				}
			} else {
				throw new IllegalArgumentException("Unsupported type: " + leftValue.getClass());
			}
		}
		return result;
	}

	private List<String> groupKeys(Map<String, Object> line, List<String> select) {
		List<String> measureColumns = select.stream()
				.filter(col -> col.contains("."))
				.map(col -> col.split("\\.")[0])
				.collect(Collectors.toList());

		return line.keySet()
				.stream()
				.filter(Predicate.not(measureColumns::contains))
				.map(line::get)
				.map(String::valueOf)
				.collect(Collectors.toList());
	}

	private Map<String, Object> project(List<String> select, Map<String, Object> line) {
		List<String> projection = getResultProjection(select);
		Map<String, Object> projected = new TreeMap<>(line);
		projected.keySet().retainAll(projection);
		return projected;
	}

	private List<String> getResultProjection(List<String> select) {
		return select.stream().map(column -> {
			if (column.contains(".")) {
				String[] split = column.split("\\.");
				String aggregation = split[1];
				if (!"SUM".equalsIgnoreCase(aggregation)) {
					throw new IllegalArgumentException(
							"Only SUM aggregation is supported, but " + aggregation + " is used");
				}
				return split[0];
			} else {
				return column;
			}
		}).collect(Collectors.toList());
	}

	private Predicate<Map<String, Object>> predict(List<Filter> filters) {
		return line -> filters.stream().allMatch(wherePredict(line));
	}

	private static Predicate<Filter> wherePredict(Map<String, Object> line) {
		return filter -> {
			final String column = filter.keySet().stream().findFirst().orElseThrow();
			Condition condition = filter.get(column);
			Object value = line.get(column);
			return condition.keySet().stream().allMatch(op -> op.predict(condition.get(op), value));
		};
	}

	@Override
	public Metadata discovery() {
		return this.metadata;
	}

	/**
	 * Dummy implementation of bookmarks list. This implementation does not take account user. It always return the same
	 * list.
	 *
	 * @return read-only bookmarks
	 */
	@Override
	public List<Bookmark> getBookmarks() {
		return bookmarks;
	}

}
