package io.olapless.for_excel.springboot;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

/**
 * CORS configuration through all components
 *
 * @author Benoit Lacelle
 *
 */
public class OlaplessForExcelCorsConfiguration {

	protected OlaplessForExcelCorsConfiguration() {
		// hidden
	}

	public static String[] getAllowedOrigins() {
		return new String[] { "http://localhost",
				"http://localhost:4000",
				"http://localhost:4001",
				"http://localhost:8080",
				"http://localhost:9000",
				"http://localhost:9001",
				"http://localhost:8081",
				"https://localhost:8443" };
	}

	public static boolean isAllowCredentials() {
		return true;
	}

	public static String[] getAllowedMethods() {
		return new String[] { HttpMethod.OPTIONS.name(),
				HttpMethod.GET.name(),
				HttpMethod.DELETE.name(),
				HttpMethod.POST.name(),
				HttpMethod.PATCH.name(),
				HttpMethod.PUT.name() };
	}

	public static String[] getAlloweHeaders() {
		return new String[] { HttpHeaders.AUTHORIZATION, HttpHeaders.CONTENT_TYPE };
	}

	public static String[] getExposedHeaders() {
		return new String[] { HttpHeaders.CONTENT_DISPOSITION };
	}
}
