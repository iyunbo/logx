package io.olapless.for_excel.springboot.service;

/**
 * dummy implementation of Forex service
 * <p>
 * we suppose all amount are based on EUR so that the exchange rate depends only the reference currency
 *
 * @author Yunbo WANG
 */
public enum Currency {
	USD(1.08), CNY(7.66), BTC(0.000_16), JPY(117.16), EUR(1);

	private double rate;

	Currency(double rate) {
		this.rate = rate;
	}

	public static Currency getDefault() {
		return EUR;
	}

	public double getRate() {
		return rate;
	}
}
