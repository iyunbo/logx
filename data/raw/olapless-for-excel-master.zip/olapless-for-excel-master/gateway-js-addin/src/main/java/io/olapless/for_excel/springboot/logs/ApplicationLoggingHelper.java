package io.olapless.for_excel.springboot.logs;

import java.lang.Thread.UncaughtExceptionHandler;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.bridge.SLF4JBridgeHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

import com.google.common.base.Strings;

/**
 * Helper to configure some extra informations for the logging system.
 *
 * @author Benoit Lacelle
 */
public final class ApplicationLoggingHelper {
	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationLoggingHelper.class);

	public static final String KEY_APPLICATION_NAME = "spring.application.name";

	private static final String JVM_ID = UUID.randomUUID().toString();
	private static final String HOST_NAME = safeGetHostName();

	protected ApplicationLoggingHelper() {
		// hidden
	}

	private static ClassLoader getClassLoader() {
		return Thread.currentThread().getContextClassLoader();
	}

	private static String safeGetHostName() {
		String hostName;
		try {
			hostName = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			LOGGER.warn("Issue resolving localhost InetAddress.getLocalHost().getHostName()", e);
			hostName = "not_resolved";
		}
		return hostName;
	}

	/**
	 * Wire technical configuration, in a static fashion so that is can be called very early. However, it might not be
	 * executed in the most relevant ClassLoader context, then we advise executing this class as a Spring {@link Bean}
	 */
	public static void configureLogger() {
		LOGGER.info("Processing ClassLoader {}", getClassLoader());

		handleSlf4jBridge();

		registerDefaultUncaughtExceptionHandler(new LoggingUncaughtExceptionHandler());
	}

	private static void handleSlf4jBridge() {
		SLF4JBridgeHandler.removeHandlersForRootLogger();
		SLF4JBridgeHandler.install();
	}

	public static void registerDefaultUncaughtExceptionHandler(UncaughtExceptionHandler eh) {
		Thread.setDefaultUncaughtExceptionHandler(eh);
	}

	public static void logMemoryInfo() {
		// Retrieve memory managed bean from management factory.
		MemoryMXBean memBean = ManagementFactory.getMemoryMXBean();
		MemoryUsage heap = memBean.getHeapMemoryUsage();
		MemoryUsage nonHeap = memBean.getNonHeapMemoryUsage();

		LOGGER.info("Heap: {}", heap);
		LOGGER.info("NonHeap: {}", nonHeap);
	}

	public static void logApplicationStartup(Environment env) {
		String protocol = "http";
		if (env.getProperty("server.ssl.key-store") != null) {
			protocol = "https";
		}
		String serverPort = env.getProperty("server.port");
		String contextPath = env.getProperty("server.servlet.context-path");
		if (Strings.isNullOrEmpty(contextPath)) {
			contextPath = "/";
		}
		String hostAddress = "localhost";
		try {
			hostAddress = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			LOGGER.warn("The host name could not be determined, using `localhost` as fallback");
		}
		LOGGER.info(
				"\n----------------------------------------------------------\n\t"
						+ "Application '{}' is running! Access URLs:\n\t"
						+ "Local: \t\t{}://localhost:{}{}\n\t"
						+ "External: \t{}://{}:{}{}\n\t"
						+ "Profile(s): \t{}\n----------------------------------------------------------",
				env.getProperty(KEY_APPLICATION_NAME),
				protocol,
				serverPort,
				contextPath,
				protocol,
				hostAddress,
				serverPort,
				contextPath,
				env.getActiveProfiles());
	}

	public static String getJvmId() {
		return JVM_ID;
	}

	public static String getHostName() {
		return HOST_NAME;
	}
}
