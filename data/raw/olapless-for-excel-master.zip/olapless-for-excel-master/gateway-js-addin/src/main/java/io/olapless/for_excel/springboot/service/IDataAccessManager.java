package io.olapless.for_excel.springboot.service;

import java.util.List;

import io.olapless.for_excel.springboot.dto.Bookmark;
import io.olapless.for_excel.springboot.dto.Metadata;
import io.olapless.for_excel.springboot.dto.QueryRequest;
import io.olapless.for_excel.springboot.dto.QueryResponse;

/**
 * Knows how to answers a {@link QueryRequest}
 * 
 * @author Benoit Lacelle
 *
 */
public interface IDataAccessManager {

	/**
	 * The main entry point for accessing data
	 *
	 * @param request
	 *            an SQL style query request
	 * @return the requested data
	 */
	QueryResponse query(QueryRequest request);

	/**
	 * This is typically the first entry point for a API client to call. The discovery method tells the basic and
	 * essential information about the data structure.
	 * 
	 * @return the {@link Metadata}
	 */
	Metadata discovery();

	/**
	 * Retrieving bookmarks of current user
	 * 
	 * @return list of bookmarks
	 */
	List<Bookmark> getBookmarks();
}
