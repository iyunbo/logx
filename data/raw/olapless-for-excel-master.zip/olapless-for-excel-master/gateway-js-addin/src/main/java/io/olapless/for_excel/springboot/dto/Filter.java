package io.olapless.for_excel.springboot.dto;

import java.util.TreeMap;

/**
 * A Filter defines a Condition over one column
 *
 * @author Yunbo WANG
 * @see io.olapless.for_excel.springboot.dto.Condition
 */
public class Filter extends TreeMap<String, Condition> {
	private static final long serialVersionUID = 6887513638448773776L;

	public static Filter when(final String column, Condition condition) {
		final Filter filter = new Filter();
		filter.put(column, condition);
		return filter;
	}

	public static Filter and(final String column, Condition condition) {
		return when(column, condition);
	}
}
