package io.olapless.for_excel.springboot.dto;

import java.util.List;
import java.util.TreeMap;

/**
 * Computation represents a dictionary of ComputeOperator -> List of expressions
 *
 * @author Yunbo WANG
 * @see io.olapless.for_excel.springboot.dto.ComputeOperator
 */
public class Computation extends TreeMap<ComputeOperator, List<String>> {

	private static final long serialVersionUID = -5008418415357696885L;
}
