package io.olapless.for_excel.springboot.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * the definition of one column:
 * 
 * - type: data type
 * 
 * @author Yunbo WANG
 */
public class ColumnDefinition {
	private String type;

	@JsonCreator
	public ColumnDefinition(@JsonProperty("type") String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
