package io.olapless.for_excel.springboot.dto;

import java.util.List;
import java.util.Objects;
import java.util.function.BiFunction;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * A logical operator is used to decide on which condition values are selected for a query
 *
 * @author Yunbo WANG
 */
public enum LogicalOperator {
	IN("$in") {
		public boolean predict(List<Object> criteria, Object value) {
			return Objects.nonNull(criteria) && Objects.nonNull(value) && criteria.contains(value);
		}
	},

	NOT("$not") {
		public boolean predict(List<Object> criteria, Object value) {
			return Objects.isNull(criteria) || Objects.isNull(value) || !criteria.contains(value);
		}
	},
	GT("$gt") {
		public boolean predict(List<Object> criteria, Object value) {
			return LogicalOperator
					.compare(criteria, value, this, (left, right) -> left.doubleValue() > right.doubleValue());
		}
	},
	GTE("$gte") {
		public boolean predict(List<Object> criteria, Object value) {
			return LogicalOperator
					.compare(criteria, value, this, (left, right) -> left.doubleValue() >= right.doubleValue());
		}
	},
	LT("$lt") {
		public boolean predict(List<Object> criteria, Object value) {
			return LogicalOperator
					.compare(criteria, value, this, (left, right) -> left.doubleValue() < right.doubleValue());
		}
	},
	LTE("$lte") {
		public boolean predict(List<Object> criteria, Object value) {
			return LogicalOperator
					.compare(criteria, value, this, (left, right) -> left.doubleValue() <= right.doubleValue());
		}
	};

	private final String expression;

	@JsonValue
	public String getExpression() {
		return expression;
	}

	LogicalOperator(final String expression) {
		this.expression = expression;
	}

	public abstract boolean predict(List<Object> criteria, Object value);

	private static boolean compare(final List<Object> criteria,
			Object value,
			final LogicalOperator operator,
			final BiFunction<Number, Number, Boolean> comparing) {
		if (Objects.requireNonNull(criteria).size() != 1) {
			throw new IllegalArgumentException("the " + operator + " expression accepts only one argument");
		}

		if (!(value instanceof Number) || !(criteria.get(0) instanceof Number)) {
			throw new IllegalArgumentException("the " + operator + " expression accepts only numeric values");
		}

		final Number numericValue = (Number) value;
		final Number criterion = (Number) criteria.get(0);
		return comparing.apply(numericValue, criterion);
	}
}
