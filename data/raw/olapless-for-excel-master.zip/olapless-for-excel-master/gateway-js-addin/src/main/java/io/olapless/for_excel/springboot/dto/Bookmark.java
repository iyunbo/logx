package io.olapless.for_excel.springboot.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * A bookmark is a unit of persistence of a query for later reusing and sharing
 *
 * @author Yunbo WANG
 */
public class Bookmark {

	private String name;
	private QueryRequest query;

	@JsonCreator
	public Bookmark(@JsonProperty("name") String name, @JsonProperty("query") QueryRequest query) {
		this.name = name;
		this.query = query;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public QueryRequest getQuery() {
		return query;
	}

	public void setQuery(QueryRequest query) {
		this.query = query;
	}
}
