package io.olapless.for_excel.springboot;

import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import io.olapless.for_excel.springboot.controller.DataAccessController;
import io.olapless.for_excel.springboot.controller.UserController;
import io.olapless.for_excel.springboot.service.DummyDataAccessManager;
import io.olapless.for_excel.springboot.service.IDataAccessManager;

/**
 * Main Spring {@link Configuration} to start the gateway
 * 
 * @author Benoit Lacelle
 *
 */
@Configuration
@Import({ UserController.class,
		DataAccessController.class,
		OlaplessMvcConfigurer.class,
		OlaplessForExcelSwaggerMvcConfigurer.class })
public class OlaplessForExcelSpringConfig {

	@Bean
	public IDataAccessManager dataAccessManager() {
		return new DummyDataAccessManager();
	}

	// When excel opens a dialog, it appends parameters like:
	// ?_host_Info=excel|web|16.00|en-us|c60f5cd4-bec3-4870-b56e-5f64d2983461|isDialog|
	// check https://stackoverflow.com/questions/46251131/invalid-character-found-in-the-request-target-in-spring-boot
	@Bean
	public ConfigurableServletWebServerFactory webServerFactory() {
		TomcatServletWebServerFactory factory = new TomcatServletWebServerFactory();
		factory.addConnectorCustomizers(connector -> connector.setProperty("relaxedQueryChars", "|"));
		return factory;
	}

}
