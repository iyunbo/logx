package io.olapless.for_excel.springboot.dto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

/**
 * Enables to query Olapless
 *
 * @author Benoit Lacelle
 */
public class QueryRequest {

	private List<String> select;
	private String from;
	private List<Filter> where;
	private Map<String, Computation> with;

	public List<String> getSelect() {
		return select;
	}

	public void setSelect(List<String> select) {
		this.select = select;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public List<Filter> getWhere() {
		return where;
	}

	public void setWhere(List<Filter> where) {
		this.where = where;
	}

	public Map<String, Computation> getWith() {
		return with;
	}

	public void setWith(Map<String, Computation> with) {
		this.with = with;
	}

	/**
	 * Builder for creating a QueryRequest
	 */
	public static final class Builder {
		private List<String> selectedColumns = new ArrayList<>();
		private String dataset;
		private List<Filter> filters = new ArrayList<>();
		private Map<String, Computation> withDefinition = new TreeMap<>();

		private Builder() {
		}

		public static Builder request() {
			return new Builder();
		}

		public Builder select(String... fields) {
			this.selectedColumns = Arrays.asList(fields);
			return this;
		}

		public Builder from(String from) {
			this.dataset = from;
			return this;
		}

		public Builder where(Filter... filters) {
			this.filters = Arrays.asList(filters);
			return this;
		}

		public Builder with(Map<String, Computation> with) {
			this.withDefinition = with;
			return this;
		}

		public QueryRequest build() {
			QueryRequest queryRequest = new QueryRequest();
			queryRequest.setSelect(selectedColumns);
			queryRequest.setFrom(dataset);
			queryRequest.setWhere(filters);
			queryRequest.setWith(withDefinition);
			return queryRequest;
		}
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		QueryRequest that = (QueryRequest) o;
		return Objects.equals(select, that.select) && Objects.equals(from, that.from)
				&& Objects.equals(where, that.where)
				&& Objects.equals(with, that.with);
	}

	@Override
	public int hashCode() {
		return Objects.hash(select, from, where, with);
	}
}
