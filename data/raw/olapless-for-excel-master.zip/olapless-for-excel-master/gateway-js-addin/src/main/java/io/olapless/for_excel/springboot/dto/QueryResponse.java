package io.olapless.for_excel.springboot.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Wrap a response to {@link QueryRequest}
 * 
 * @author Benoit Lacelle
 *
 */
public class QueryResponse extends ArrayList<Map<String, Object>> {

	private static final long serialVersionUID = -3460126096970002889L;

	public QueryResponse() {
		super();
	}

	private QueryResponse(List<Map<String, Object>> data) {
		super(data);
	}

	public static QueryResponse of(List<Map<String, Object>> data) {
		return new QueryResponse(data);
	}
}
